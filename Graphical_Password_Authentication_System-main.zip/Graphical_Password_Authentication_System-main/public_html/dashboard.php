<!DOCTYPE html>
<html>
<body style='background: url("16692.webp");'>
<center><div style="background-color: green; color: white; font-size: 200%; width: 240px; box-shadow: 0px 2px 5px black; margin-bottom: 30px;">Welcome<br>Login Successful</div></center>

</body>
</html>