function validate(){
    var h = document.getElementById('name').value;
    if (h==""){
        alert('please enter an email id');
    }
    else {
        window.location.href="http://zeitx.ml/forgot2.php"
    }
}